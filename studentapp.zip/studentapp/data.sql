create table Students;


INSERT INTO students (name, age, department) VALUES 
('Hari', 22, 'Computer Science'),
('Hemashree', 23, 'Mechanical Engineering'),
('Nithish', 21, 'Electrical Engineering');